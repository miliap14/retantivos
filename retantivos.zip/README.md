# retantivos
Creación de valores para retantivos
